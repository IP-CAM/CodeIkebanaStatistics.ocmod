<?php

$_['heading_title'] = "Codeikebana Statistics";

// Text
$_['text_extension']            = 'Extensions';
$_['text_success']              = 'Success: You have modified statistics module!';
$_['text_edit']                 = 'Edit Codeikebana Statistics';
$_['text_general']              = 'General';
$_['text_statistics']           = 'Statistics';
$_['text_compleate_statuses']   = 'Compleate statuses';
$_['text_processing_statuses']  = 'Processing statuses';
$_['text_statuses_info']        = 'Above statuses are selected in settings. Total order sale is a sum of all order totals that have either compleate or processing statuses';
$_['text_statistic_code']       = 'Statistic code';
$_['text_statistic_value']      = 'Saved value';
$_['text_statistic_current']    = 'Current value';
$_['text_statistic_options']    = 'Options';
$_['text_statistics_refresh']   = 'Refresh';
$_['text_error_or_not_supported']   = 'Error occured or this feature is not supported';

// Entry
$_['entry_status']            = 'Status';